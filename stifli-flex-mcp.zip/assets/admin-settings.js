(function(){
	// Admin settings JavaScript for StifLi Flex MCP
	// Authentication is now handled via WordPress Application Passwords
	// No custom token management needed
	
	// Copy functionality is now inline in the PHP template using onclick handlers
})();

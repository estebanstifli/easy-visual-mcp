<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class EasyVisualMcpController {
	// Puedes extender de una clase base si lo necesitas
}
